<footer role="contentinfo" class="bg-carton">
    <div class="row copyright">
        <div class="col-md-12 text-center">
            <p>
                <!-- <small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small> -->
                <small class="block">&copy; 2022 Nandur Studio. All Rights Reserved.</small>
                <!-- <small class="block">Designed by <a href="http://freehtml5.co/" target="_blank">FREEHTML5.co</a> Demo Images: <a href="http://unsplash.co/" target="_blank">Unsplash</a></small> -->
							<small class="block">Web Invitation by <a href="https://www.nandurstudio.com" target="_blank">Nandur Studio Event</a>
								</br>Design by <a href="https://instagram.com/nandur.studio" target="_blank">Nandur Studio</a>
                    </br>Master Template: <a href="http://freehtml5.co/" target="_blank">&copy; 2016 Free HTML5. All Rights Reserved.</a></small>
            </p>
            <p>
            <ul class="fh5co-social-icons">
                <li><a href="https://twitter.com/NandurStudio"><i class="icon-twitter"></i></a></li>
                <li><a href="https://web.facebook.com/n93animasi"><i class="icon-facebook"></i></a></li>
                <li><a href="https://www.linkedin.com/in/nandangduryat/"><i class="icon-linkedin"></i></a></li>
                <li><a href="https://dribbble.com/nandur93"><i class="icon-dribbble"></i></a></li>
            </ul>
            </p>
        </div>
    </div>
</footer>
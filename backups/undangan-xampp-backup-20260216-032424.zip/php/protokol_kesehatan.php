    <div class="row">
        <div class="animate-box just-center">
            <p>This event is carried out by implementing the following health protocols:</br>
            <img class="protokol-image" src="./images/protokol_en.png" />
            <p>Without reducing respect, in order to reduce the spread of the pandemic, please always follow the health protocols and arrive on time according to the hours listed on the invitation.</p>
            <p>Press the close button to close this information/this information will be closed automatically after 15 seconds.</p>
        </div>
    </div>